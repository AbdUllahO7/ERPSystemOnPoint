export * from "./resources.service";
